Writing Without Limits Website

How to use:
1. Open index.html in your browser
2. Add more stories inside /stories folder
3. Duplicate story1.html for new submissions
